create function decrement_like_count() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Check if visibility is changing from TRUE to FALSE
    IF NEW.visible = FALSE AND OLD.visible = TRUE THEN
        -- Decrease like_count only if it's greater than 0, and treat NULL as 0
        UPDATE articles
        SET like_count = CASE
                             WHEN COALESCE(like_count, 0) > 0 THEN COALESCE(like_count, 0) - 1
                             ELSE 0  -- Ensure it doesn't go below 0
            END
        WHERE id = NEW.article_id;
    END IF;

    RETURN NEW;
END;
$$;

alter function decrement_like_count() owner to postgres;

