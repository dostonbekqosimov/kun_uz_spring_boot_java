create function increment_view_count() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the viewCount in the Article table
    UPDATE articles
    SET view_count = COALESCE(view_count, 0) + 1
    WHERE id = NEW.article_id;

    RETURN NEW;
END;
$$;

alter function increment_view_count() owner to postgres;

