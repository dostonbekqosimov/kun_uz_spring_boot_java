create function increment_like_count() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Update the likeCount in the Article table
    UPDATE articles
    SET like_count = COALESCE(like_count, 0) + 1
    WHERE id = NEW.article_id;

    RETURN NEW;
END;
$$;

alter function increment_like_count() owner to postgres;

